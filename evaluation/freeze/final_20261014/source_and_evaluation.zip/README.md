# Research Compass

Day 2 MVP: an exploratory search web app for early-stage researchers. It shows the path from a vague interest through two optional clarification questions, editable structured intent, distinct search directions, and abstract-grounded exploration of real OpenAlex papers.

## Start locally

Use Python 3.11 or newer in a virtual environment, then install dependencies:

```powershell
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local address shown by Streamlit, usually `http://localhost:8501`.

For reliable live search, create a **free** [OpenAlex API key](https://openalex.org/settings/api) and set it locally before starting the app:

```powershell
$env:OPENALEX_API_KEY = "your-free-key"
streamlit run app.py
```

Alternatively, put the key in local `.streamlit/secrets.toml` or Streamlit Cloud Secrets. The real secrets file and `.env` files are ignored by Git. Never commit or publish a key.

The app also loads `OPENALEX_API_KEY` from a local `.env` file. You can create one containing `OPENALEX_API_KEY=your-free-key`; `.env` is Git-ignored.

## Demo path

1. Enter an English research interest such as `AI for robot control`.
2. Choose a focus and optional context, or skip clarification.
3. Check the suggested research theme and approach; select or edit the technique, task, and evaluation search directions.
4. Search and inspect the separate **new plan** and **Day 1 Baseline** result tabs.
5. Read exact abstract excerpts, individually sourced limitations, and candidate questions marked **unverified**.
6. Download the paired JSON trace for later evidence validation and evaluation.

The Day 1 keyword templates remain unchanged as a separately retrieved Baseline. The Day 2 intent split and evidence extraction are transparent rules, **not LLM-generated research conclusions**. The JSON records original queries, per-query ranked paper IDs, paper metadata and abstracts, evidence quotes, inferred questions, timestamps, and live/partial/demo status for both plans. If OpenAlex is unavailable, the app clearly switches to **DEMO mode** with fictional cards and no paper links. Demo records never generate a research report. An empty successful search stays empty; it is not filled with demo records. Abstracts are not claims of full-text verification.

## Current scope

The app retrieves papers through [PyAlex](https://github.com/J535D165/pyalex) and the [OpenAlex API](https://help.openalex.org/api/searching/). The landscape describes only the retrieved sample. Status and limitation cards quote individual abstracts verbatim with links. Candidate research questions are system-inferred drafts, not established research gaps. OpenAlex ranking may include off-topic results or very short abstracts; short abstracts are excluded from evidence extraction. Systematic evidence validation, better relevance filtering, and offline baseline evaluation remain for Day 3.

Run focused tests with `python -m pytest -q`.
