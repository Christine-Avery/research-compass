﻿"""Research Compass explicit Streamlit page registry."""

import streamlit as st

home_page = st.Page(
    "pages/1_Home.py",
    title="Research Compass",
    default=True,
)
evaluation_page = st.Page(
    "pages/2_Evaluation.py",
    title="人工评测 Evaluation",
    url_path="evaluation",
)

# Main-content page links are available on both routes, so the app does not
# depend on the sidebar being visible.
navigation = st.navigation([home_page, evaluation_page], position="hidden")
navigation.run()
